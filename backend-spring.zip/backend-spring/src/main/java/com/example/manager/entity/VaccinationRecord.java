package com.example.manager.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "vaccination_records")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VaccinationRecord {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "record_id")
    private Long recordId;

    @ManyToOne
    @JoinColumn(name = "campaign_id")
    private VaccinationCampaign campaign;

    @Column(name = "student_id")
    private Long studentId;

    @Column(name = "vaccine_date")
    private LocalDate vaccineDate;

    @Column(name = "dose_number")
    private Integer doseNumber;

    @Column(name = "status", length = 20)
    private String status;

    @Column(name = "notes", columnDefinition = "TEXT")
    private String notes;

    @Column(name = "vaccinated_by")
    private Long vaccinatedBy;

    @Column(name = "created_at")
    private LocalDateTime createdAt;
} 