package com.example.manager.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "medicalevent")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MedicalEvent {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "event_id")
    private Long eventId;

    @Column(name = "student_id")
    private Long studentId;

    @Column(name = "nurse_id")
    private Long nurseId;

    @Column(name = "event_type", length = 50)
    private String eventType;

    @Column(name = "descriptions", columnDefinition = "TEXT")
    private String descriptions;

    @Column(name = "date_time")
    private LocalDateTime dateTime;

    @Column(name = "actions_taken", columnDefinition = "TEXT")
    private String actionsTaken;

    @Column(name = "status", length = 50)
    private String status;
} 