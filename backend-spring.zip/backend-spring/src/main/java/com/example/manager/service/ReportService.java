// ReportService.java
package com.example.manager.service;

import com.example.manager.model.Report;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReportService {
    public List<Report> getReports() {
        return List.of(
            new Report("Vaccination", "80% of students vaccinated"),
            new Report("Events", "1 outbreak handled"),
            new Report("Inventory", "3 items low stock")
        );
    }
}
