// VaccinationCampaignService.java
package com.example.manager.service;

import com.example.manager.model.VaccinationCampaign;
import com.example.manager.repository.VaccinationCampaignRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VaccinationCampaignService {
    private final VaccinationCampaignRepository repo;

    public VaccinationCampaignService(VaccinationCampaignRepository repo) {
        this.repo = repo;
    }

    public List<VaccinationCampaign> getAll() {
        return repo.findAll();
    }

    public VaccinationCampaign update(Long id, VaccinationCampaign data) {
        return repo.findById(id).map(v -> {
            v.setName(data.getName());
            v.setProgress(data.getProgress());
            v.setResult(data.getResult());
            return repo.save(v);
        }).orElseThrow();
    }
}
