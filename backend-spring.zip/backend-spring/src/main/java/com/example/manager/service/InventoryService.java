// InventoryService.java
package com.example.manager.service;

import com.example.manager.model.InventoryItem;
import com.example.manager.repository.InventoryItemRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventoryService {
    private final InventoryItemRepository repo;

    public InventoryService(InventoryItemRepository repo) {
        this.repo = repo;
    }

    public List<InventoryItem> getAll() {
        return repo.findAll();
    }

    public InventoryItem create(InventoryItem item) {
        return repo.save(item);
    }

    public InventoryItem update(Long id, InventoryItem data) {
        return repo.findById(id).map(i -> {
            i.setItemName(data.getItemName());
            i.setQuantity(data.getQuantity());
            i.setRestockRequested(data.isRestockRequested());
            return repo.save(i);
        }).orElseThrow();
    }
}
