// VaccinationCampaignController.java
package com.example.manager.controller;

import com.example.manager.model.VaccinationCampaign;
import com.example.manager.service.VaccinationCampaignService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/vaccination-campaigns")
@CrossOrigin
public class VaccinationCampaignController {
    private final VaccinationCampaignService service;

    public VaccinationCampaignController(VaccinationCampaignService service) {
        this.service = service;
    }

    @GetMapping
    public List<VaccinationCampaign> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public VaccinationCampaign update(@PathVariable Long id, @RequestBody VaccinationCampaign data) {
        return service.update(id, data);
    }
}
