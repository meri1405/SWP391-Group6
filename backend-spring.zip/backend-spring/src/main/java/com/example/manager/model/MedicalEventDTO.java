package com.example.manager.model;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class MedicalEventDTO {
    private Long eventId;
    private Long studentId;
    private Long nurseId;
    private String eventType;
    private String descriptions;
    private LocalDateTime dateTime;
    private String actionsTaken;
    private String status;
} 