// HealthCheckupController.java
package com.example.manager.controller;

import com.example.manager.model.HealthCheckup;
import com.example.manager.service.HealthCheckupService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/health-checkups")
@CrossOrigin
public class HealthCheckupController {
    private final HealthCheckupService service;

    public HealthCheckupController(HealthCheckupService service) {
        this.service = service;
    }

    @GetMapping
    public List<HealthCheckup> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public HealthCheckup update(@PathVariable Long id, @RequestBody HealthCheckup data) {
        return service.update(id, data);
    }
}
