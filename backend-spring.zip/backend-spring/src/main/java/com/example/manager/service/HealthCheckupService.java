// HealthCheckupService.java
package com.example.manager.service;

import com.example.manager.model.HealthCheckup;
import com.example.manager.repository.HealthCheckupRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HealthCheckupService {
    private final HealthCheckupRepository repo;

    public HealthCheckupService(HealthCheckupRepository repo) {
        this.repo = repo;
    }

    public List<HealthCheckup> getAll() {
        return repo.findAll();
    }

    public HealthCheckup update(Long id, HealthCheckup data) {
        return repo.findById(id).map(h -> {
            h.setDate(data.getDate());
            h.setStudentList(data.getStudentList());
            h.setParticipationRate(data.getParticipationRate());
            return repo.save(h);
        }).orElseThrow();
    }
}
