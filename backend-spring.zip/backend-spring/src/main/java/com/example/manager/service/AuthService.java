package com.example.manager.service;

import com.example.manager.dto.AuthResponse;
import com.example.manager.dto.EmailLoginRequest;
import com.example.manager.dto.LoginRequest;
import com.example.manager.dto.OtpVerificationRequest;
import com.example.manager.dto.RegisterRequest;
import com.example.manager.entity.Role;
import com.example.manager.entity.User;
import com.example.manager.repository.RoleRepository;
import com.example.manager.repository.UserRepository;
import com.example.manager.security.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private OtpService otpService;

    public AuthResponse register(RegisterRequest request) {
        // Check if username exists
        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            return new AuthResponse(null, null, null, "Username already exists");
        }

        // Create new user
        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setDob(request.getDob());
        user.setGender(request.getGender());
        user.setPhone(request.getPhone());
        user.setEmail(request.getEmail());
        user.setAddress(request.getAddress());
        user.setJobTitle(request.getJobTitle());
        user.setCreatedDate(LocalDateTime.now());
        user.setEnabled(true);

        // Set role as MANAGER
        Role managerRole = roleRepository.findByRoleName("MANAGER")
                .orElseThrow(() -> new RuntimeException("Manager role not found"));
        user.setRole(managerRole);

        userRepository.save(user);

        // Generate token
        String token = jwtTokenProvider.generateToken(user.getUsername());

        return new AuthResponse(token, user.getUsername(), user.getRole().getRoleName(), "Registration successful");
    }

    public AuthResponse login(LoginRequest request) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
            );

            User user = userRepository.findByUsername(request.getUsername())
                    .orElseThrow(() -> new RuntimeException("User not found"));

            String token = jwtTokenProvider.generateToken(user.getUsername());

            return new AuthResponse(token, user.getUsername(), user.getRole().getRoleName(), "Login successful");
        } catch (Exception e) {
            return new AuthResponse(null, null, null, "Invalid username or password");
        }
    }

    public AuthResponse initiateEmailLogin(EmailLoginRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        String otp = otpService.generateOtp();
        otpService.saveOtp(request.getEmail(), otp);
        otpService.sendOtpEmail(request.getEmail(), otp);

        return new AuthResponse(null, user.getUsername(), user.getRole().getRoleName(), "OTP sent to your email");
    }

    public AuthResponse verifyOtpAndLogin(OtpVerificationRequest request) {
        if (!otpService.verifyOtp(request.getEmail(), request.getOtp())) {
            return new AuthResponse(null, null, null, "Invalid OTP");
        }

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        String token = jwtTokenProvider.generateToken(user.getUsername());
        return new AuthResponse(token, user.getUsername(), user.getRole().getRoleName(), "Login successful");
    }
} 