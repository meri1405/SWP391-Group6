// VaccinationCampaignRepository.java
package com.example.manager.repository;

import com.example.manager.model.VaccinationCampaign;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VaccinationCampaignRepository extends JpaRepository<VaccinationCampaign, Long> {}
