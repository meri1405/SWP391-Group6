 package com.example.manager.dto;

import lombok.Data;

@Data
public class EmailLoginRequest {
    private String email;
}