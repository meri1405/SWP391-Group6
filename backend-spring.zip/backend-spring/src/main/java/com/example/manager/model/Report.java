package com.example.manager.model;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Report {
    private String type;
    private String content;
}
