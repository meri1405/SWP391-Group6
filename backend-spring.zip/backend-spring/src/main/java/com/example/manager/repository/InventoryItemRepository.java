// InventoryItemRepository.java
package com.example.manager.repository;

import com.example.manager.model.InventoryItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryItemRepository extends JpaRepository<InventoryItem, Long> {}
