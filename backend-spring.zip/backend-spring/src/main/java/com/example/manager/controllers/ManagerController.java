package com.example.manager.controller;

import com.example.manager.model.Event;
import com.example.manager.service.EventService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/events")
@CrossOrigin(origins = "*")
public class ManagerController {

    private final EventService service;

    public ManagerController(EventService service) {
        this.service = service;
    }

    @GetMapping
    public List<Event> getAllEvents() {
        return service.getAllEvents();
    }

    @PutMapping("/{id}")
    public Event updateEvent(@PathVariable Long id, @RequestBody Event newData) {
        return service.updateEvent(id, newData);
    }
}
