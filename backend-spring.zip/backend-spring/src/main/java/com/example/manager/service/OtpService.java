package com.example.manager.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Service
public class OtpService {

    @Autowired
    private JavaMailSender emailSender;

    // Lưu trữ OTP tạm thời (trong thực tế nên dùng Redis)
    private final Map<String, String> otpMap = new HashMap<>();

    public String generateOtp() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000);
        return String.valueOf(otp);
    }

    public void sendOtpEmail(String to, String otp) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject("Your OTP for Login");
        message.setText("Your OTP is: " + otp + "\nThis OTP will expire in 5 minutes.");
        emailSender.send(message);
    }

    public void saveOtp(String email, String otp) {
        otpMap.put(email, otp);
    }

    public boolean verifyOtp(String email, String otp) {
        String savedOtp = otpMap.get(email);
        if (savedOtp != null && savedOtp.equals(otp)) {
            otpMap.remove(email); // Xóa OTP sau khi xác thực thành công
            return true;
        }
        return false;
    }
} 