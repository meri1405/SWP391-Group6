// ReportController.java
package com.example.manager.controller;

import com.example.manager.model.Report;
import com.example.manager.service.ReportService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin
public class ReportController {
    private final ReportService service;

    public ReportController(ReportService service) {
        this.service = service;
    }

    @GetMapping
    public List<Report> getReports() {
        return service.getReports();
    }
}
