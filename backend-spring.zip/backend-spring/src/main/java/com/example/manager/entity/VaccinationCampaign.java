package com.example.manager.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Entity
@Table(name = "vaccinationcampaign")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VaccinationCampaign {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "campaign_id")
    private Long campaignId;

    @Column(name = "name", length = 100)
    private String name;

    @Column(name = "vaccine_type", length = 100)
    private String vaccineType;

    @Column(name = "planned_date")
    private LocalDate plannedDate;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "status", length = 20)
    private String status;
} 