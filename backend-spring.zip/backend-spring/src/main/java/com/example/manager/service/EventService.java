package com.example.manager.service;

import com.example.manager.model.Event;
import com.example.manager.repository.EventRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventService {
    private final EventRepository repository;

    public EventService(EventRepository repository) {
        this.repository = repository;
    }

    public List<Event> getAllEvents() {
        return repository.findAll();
    }

    public Event updateEvent(Long id, Event newData) {
        return repository.findById(id).map(event -> {
            event.setName(newData.getName());
            event.setStatus(newData.getStatus());
            return repository.save(event);
        }).orElseThrow(() -> new RuntimeException("Event not found"));
    }
}
