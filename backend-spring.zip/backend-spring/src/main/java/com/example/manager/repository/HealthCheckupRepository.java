// HealthCheckupRepository.java
package com.example.manager.repository;

import com.example.manager.model.HealthCheckup;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HealthCheckupRepository extends JpaRepository<HealthCheckup, Long> {}
