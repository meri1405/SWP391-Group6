package group6.Swp391.Se1861.SchoolMedicalManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolMedicalManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
