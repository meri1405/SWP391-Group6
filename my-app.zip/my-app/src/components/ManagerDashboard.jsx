import React, { useState } from 'react';
import styles from './ManagerDashboard.module.css';

export default function ManagerDashboard() {
    const [selectedTab, setSelectedTab] = useState('approval');

    const renderContent = () => {
        switch (selectedTab) {
            case 'approval':
                return (
                    <div className={styles.content}>
                        <h2>Phê duyệt sự kiện y tế</h2>
                        <button>Xem chi tiết</button>
                        <button>Cập nhật trạng thái</button>
                    </div>
                );
            case 'campaign':
                return (
                    <div className={styles.content}>
                        <h2>Giám sát chiến dịch tiêm chủng</h2>
                        <button>Xem tiến độ</button>
                        <button>Chỉnh sửa thông tin</button>
                    </div>
                );
            case 'health':
                return (
                    <div className={styles.content}>
                        <h2>Giám sát khám sức khỏe định kỳ</h2>
                        <button>Xem danh sách</button>
                        <button>Cập nhật kết quả</button>
                    </div>
                );
            case 'inventory':
                return (
                    <div className={styles.content}>
                        <h2>Điều phối tồn kho</h2>
                        <button>Xem tồn kho</button>
                        <button>Thêm vật tư</button>
                        <button>Chỉnh sửa vật tư</button>
                    </div>
                );
            case 'report':
                return (
                    <div className={styles.content}>
                        <h2>Báo cáo tổng hợp</h2>
                        <button>Xem báo cáo</button>
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div className={styles.container}>
            <h1 className={styles.title}>Manager Dashboard</h1>
            <div className={styles.tabButtons}>
                <button
                    className={`${styles.tabButton} ${selectedTab === 'approval' ? styles.activeTab : ''}`}
                    onClick={() => setSelectedTab('approval')}
                >
                    Phê duyệt sự kiện y tế
                </button>
                <button
                    className={`${styles.tabButton} ${selectedTab === 'campaign' ? styles.activeTab : ''}`}
                    onClick={() => setSelectedTab('campaign')}
                >
                    Chiến dịch tiêm chủng
                </button>
                <button
                    className={`${styles.tabButton} ${selectedTab === 'health' ? styles.activeTab : ''}`}
                    onClick={() => setSelectedTab('health')}
                >
                    Khám sức khỏe
                </button>
                <button
                    className={`${styles.tabButton} ${selectedTab === 'inventory' ? styles.activeTab : ''}`}
                    onClick={() => setSelectedTab('inventory')}
                >
                    Tồn kho
                </button>
                <button
                    className={`${styles.tabButton} ${selectedTab === 'report' ? styles.activeTab : ''}`}
                    onClick={() => setSelectedTab('report')}
                >
                    Báo cáo
                </button>
            </div>
            {renderContent()}
        </div>
    );
}
