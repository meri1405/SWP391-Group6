import React from "react";

const tasks = [
    {
        name: "Phê duyệt sự kiện y tế",
        description: "Dịch bệnh, sự cố quy mô lớn cần xử lý và báo cáo",
        permissions: { xem: true, them: false, sua: true, xoa: false },
    },
    {
        name: "Giám sát chiến dịch tiêm chủng",
        description: "Theo dõi tiến độ, kết quả tiêm chủng toàn trường",
        permissions: { xem: true, them: false, sua: true, xoa: false },
    },
    {
        name: "Giám sát đợt khám sức khỏe định kỳ",
        description: "Xem danh sách học sinh, kết quả và tỷ lệ tham gia",
        permissions: { xem: true, them: false, sua: true, xoa: false },
    },
    {
        name: "Điều phối tồn kho",
        description: "Cân đối thuốc, vật tư khi có yêu cầu → xử lý request restock",
        permissions: { xem: true, them: true, sua: true, xoa: false },
    },
    {
        name: "Truy cập báo cáo tổng hợp",
        description: "Xem thống kê tiêm chủng, sự kiện y tế, hồ sơ học sinh",
        permissions: { xem: true, them: false, sua: false, xoa: false },
    },
];

function ManagerPermissions() {
    return (
        <div style={{ padding: 20 }}>
            <h2>Quản lý quyền của Manager</h2>
            <table border="1" cellPadding="8" cellSpacing="0" style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                    <tr>
                        <th>Tasks</th>
                        <th>Mô tả</th>
                        <th>Xem</th>
                        <th>Thêm</th>
                        <th>Sửa</th>
                        <th>Xóa</th>
                    </tr>
                </thead>
                <tbody>
                    {tasks.map(({ name, description, permissions }, idx) => (
                        <tr key={idx}>
                            <td>{name}</td>
                            <td>{description}</td>
                            <td>
                                <input type="checkbox" checked={permissions.xem} readOnly />
                            </td>
                            <td>
                                <input type="checkbox" checked={permissions.them} readOnly />
                            </td>
                            <td>
                                <input type="checkbox" checked={permissions.sua} readOnly />
                            </td>
                            <td>
                                <input type="checkbox" checked={permissions.xoa} readOnly />
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default ManagerPermissions;
