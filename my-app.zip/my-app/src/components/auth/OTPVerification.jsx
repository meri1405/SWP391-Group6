import React, { useState } from 'react';
import {
    Box,
    Button,
    TextField,
    Typography,
    Container,
    Paper,
    Alert,
    CircularProgress
} from '@mui/material';
import axios from 'axios';

const OTPVerification = ({ email, onVerificationSuccess }) => {
    const [otp, setOtp] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const [resendDisabled, setResendDisabled] = useState(false);
    const [countdown, setCountdown] = useState(0);

    const handleVerifyOTP = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        try {
            const response = await axios.post('http://localhost:8080/api/auth/verify-otp', {
                email,
                otp
            });

            if (response.data.success) {
                onVerificationSuccess(response.data);
            }
        } catch (err) {
            setError(err.response?.data?.message || 'Invalid OTP. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    const handleResendOTP = async () => {
        setResendDisabled(true);
        setCountdown(60);

        try {
            await axios.post('http://localhost:8080/api/auth/resend-otp', { email });

            const timer = setInterval(() => {
                setCountdown((prev) => {
                    if (prev <= 1) {
                        clearInterval(timer);
                        setResendDisabled(false);
                        return 0;
                    }
                    return prev - 1;
                });
            }, 1000);
        } catch (err) {
            setError('Failed to resend OTP. Please try again.');
            setResendDisabled(false);
        }
    };

    return (
        <Container component="main" maxWidth="xs">
            <Paper elevation={3} sx={{ p: 4, mt: 8 }}>
                <Typography component="h1" variant="h5" align="center" gutterBottom>
                    Verify Your Email
                </Typography>

                <Typography variant="body2" align="center" sx={{ mb: 3 }}>
                    We have sent a verification code to {email}
                </Typography>

                {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

                <Box component="form" onSubmit={handleVerifyOTP}>
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        label="Enter OTP"
                        name="otp"
                        value={otp}
                        onChange={(e) => setOtp(e.target.value)}
                        inputProps={{ maxLength: 6 }}
                    />

                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        disabled={loading}
                        sx={{ mt: 3, mb: 2 }}
                    >
                        {loading ? <CircularProgress size={24} /> : 'Verify OTP'}
                    </Button>

                    <Button
                        fullWidth
                        variant="text"
                        onClick={handleResendOTP}
                        disabled={resendDisabled}
                        sx={{ mt: 1 }}
                    >
                        {resendDisabled
                            ? `Resend OTP in ${countdown}s`
                            : 'Resend OTP'}
                    </Button>
                </Box>
            </Paper>
        </Container>
    );
};

export default OTPVerification; 