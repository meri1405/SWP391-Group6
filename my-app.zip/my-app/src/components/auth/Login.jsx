import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import {
    Box,
    Button,
    TextField,
    Typography,
    Container,
    Paper,
    Alert,
    Tabs,
    Tab,
    Divider,
    CircularProgress,
    Card,
    CardContent,
    Stack
} from '@mui/material';
import GoogleIcon from '@mui/icons-material/Google';
import EmailIcon from '@mui/icons-material/Email';
import LockIcon from '@mui/icons-material/Lock';
import OTPVerification from './OTPVerification';

const Login = () => {
    const navigate = useNavigate();
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const [loginMethod, setLoginMethod] = useState('password');
    const [email, setEmail] = useState('');
    const [showOTP, setShowOTP] = useState(false);
    const [formData, setFormData] = useState({
        username: '',
        password: ''
    });

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        try {
            if (loginMethod === 'password') {
                const response = await axios.post('http://localhost:8080/api/auth/login', formData);
                handleLoginSuccess(response.data);
            } else {
                await axios.post('http://localhost:8080/api/auth/send-otp', { email });
                setShowOTP(true);
            }
        } catch (err) {
            setError(err.response?.data?.message || 'Login failed. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    const handleGoogleLogin = async () => {
        try {
            window.location.href = 'http://localhost:8080/api/auth/google';
        } catch (err) {
            setError('Google login failed. Please try again.');
        }
    };

    const handleLoginSuccess = (data) => {
        if (data.token) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify({
                username: data.username,
                role: data.role
            }));
            navigate('/dashboard');
        }
    };

    const handleOTPVerificationSuccess = (data) => {
        handleLoginSuccess(data);
    };

    if (showOTP) {
        return <OTPVerification email={email} onVerificationSuccess={handleOTPVerificationSuccess} />;
    }

    return (
        <Container component="main" maxWidth="sm">
            <Paper elevation={3} sx={{ p: 4, mt: 8 }}>
                <Typography component="h1" variant="h5" align="center" gutterBottom>
                    Welcome Back
                </Typography>
                <Typography variant="body2" align="center" color="text.secondary" sx={{ mb: 4 }}>
                    Please choose your login method
                </Typography>

                {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

                <Stack spacing={2}>
                    <Card variant="outlined" sx={{ cursor: 'pointer' }} onClick={() => setLoginMethod('password')}>
                        <CardContent>
                            <Stack direction="row" spacing={2} alignItems="center">
                                <LockIcon color="primary" />
                                <Box>
                                    <Typography variant="h6">Login with Password</Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Use your username and password
                                    </Typography>
                                </Box>
                            </Stack>
                        </CardContent>
                    </Card>

                    <Card variant="outlined" sx={{ cursor: 'pointer' }} onClick={() => setLoginMethod('otp')}>
                        <CardContent>
                            <Stack direction="row" spacing={2} alignItems="center">
                                <EmailIcon color="primary" />
                                <Box>
                                    <Typography variant="h6">Login with OTP</Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Get a one-time password sent to your email
                                    </Typography>
                                </Box>
                            </Stack>
                        </CardContent>
                    </Card>

                    <Card variant="outlined" sx={{ cursor: 'pointer' }} onClick={handleGoogleLogin}>
                        <CardContent>
                            <Stack direction="row" spacing={2} alignItems="center">
                                <GoogleIcon color="primary" />
                                <Box>
                                    <Typography variant="h6">Continue with Google</Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Sign in with your Google account
                                    </Typography>
                                </Box>
                            </Stack>
                        </CardContent>
                    </Card>
                </Stack>

                <Box component="form" onSubmit={handleSubmit} sx={{ mt: 4 }}>
                    {loginMethod === 'password' ? (
                        <>
                            <TextField
                                margin="normal"
                                required
                                fullWidth
                                label="Username"
                                name="username"
                                value={formData.username}
                                onChange={handleChange}
                            />
                            <TextField
                                margin="normal"
                                required
                                fullWidth
                                label="Password"
                                type="password"
                                name="password"
                                value={formData.password}
                                onChange={handleChange}
                            />
                        </>
                    ) : (
                        <TextField
                            margin="normal"
                            required
                            fullWidth
                            label="Email"
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                        />
                    )}

                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        disabled={loading}
                        sx={{ mt: 3, mb: 2 }}
                    >
                        {loading ? <CircularProgress size={24} /> : 'Login'}
                    </Button>

                    <Button
                        fullWidth
                        variant="text"
                        onClick={() => navigate('/register')}
                        sx={{ mt: 1 }}
                    >
                        Don't have an account? Register
                    </Button>
                </Box>
            </Paper>
        </Container>
    );
};

export default Login; 