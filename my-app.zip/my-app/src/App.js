import React from 'react';
import ManagerDashboard from './components/ManagerDashboard';
import ManagerPermissions from "./components/ManagerPermissions";

function App() {
  return (
    <div className="App">
      <ManagerDashboard />
      {/* <ManagerPermissions /> */}
    </div>
  );
}

export default App;
